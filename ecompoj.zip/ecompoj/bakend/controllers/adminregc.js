
const bcrypt = require('bcryptjs')
const jwt=require('jsonwebtoken')
const AdminModal= require('../modals/Reg')

const secret = 'test';

exports.signin = async (req, res) => {
   
  const { email, password } = req.body;

  try {
    const oldUser = await AdminModal.findOne({ email:email});

    if (!oldUser) return res.status(404).json({ message: "User doesn't exist" });

    const isPasswordCorrect = await bcrypt.compare(password, oldUser.password);

    if (!isPasswordCorrect) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ email: oldUser.email, id: oldUser._id }, secret, { expiresIn: "1h" });

    res.status(200).json({ result: oldUser, token });
  } catch (err) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

 exports.signup = async (req, res) => {
  const { email, password } = req.body;
  
  try{
     
     const hashedPassword = await bcrypt.hash(password, 12);
     const result = await AdminModal.create({ email, password: hashedPassword });

     const token = jwt.sign( { email: result.email, id: result._id }, secret, { expiresIn: "1h" } );
 
     res.status(201).json({ result, token });
    
 
  }catch(error){
     res.json({
         status:500,
         message:'error.',
        
     })
 
  }

//   try {
//     const oldUser = await AdminModal.findOne({ email });

//     if (oldUser) return res.status(400).json({ message: "User already exists" });

//     const hashedPassword = await bcrypt.hash(password, 12);

//     const result = await AdminModal.create({ email, password: hashedPassword });

//     const token = jwt.sign( { email: result.email, id: result._id }, secret, { expiresIn: "1h" } );

//     res.status(201).json({ result, token });
//   } catch (error) {
//     res.status(500).json({ message: "Something went wrong" });
    
//     console.log(error);
//   }
};


