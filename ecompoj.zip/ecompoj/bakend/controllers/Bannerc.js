const BannerModal = require('../modals/Banner')


exports.addbanner=async(req,res)=>{
    // console.log(req.file)
    try{
        const filename= req.file.filename
        const record = await  new BannerModal ({image:filename})
        record.save()
         res.json({
          status:200,
          message:'successfully.',
          apiData:record
      })
    }catch(error){
        res.json({
            status:500,
            message:'error',
      })

    }
}
exports.showBanner=async(req,res)=>{
    try{
        const record=await BannerModal.find()
       //console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

    }
}
exports.Bannerdel=async(req,res)=>{
    const id=(req.params.id)
    try{
        await BannerModal.findByIdAndDelete(id)
        
        res.json({
            message:"successfully Deleted"
        })
    
     }catch(error){
      res.json({message:error.message})  
     }
}