import Footer from "./Footer";
import Navbar from "./Header";

function Cdt() {
    return (
        <>
       <Navbar/>
       <div style={{height:'100px'}}>
        
       </div>
       {/* <section>
       <footer className="footer-section" id="ft">
      
        <div className="container">
        <div className="footer-cta pt-5 pb-5">
                <div className="row">
                    <div className="col-xl-4 col-md-4 mb-30 ">
                    <div className="single-cta d-flex">
                    <i class="bi bi-geo-alt-fill text-danger "></i>
                            <div className="cta-text">
                         
                                <h4>Find  us</h4>
                                <span>S-15
Near Care Bear School,Amritpuri Ghat Gate Jaipur 302003</span>
                            </div>
                        </div>
                        
                    </div>
                    <div className="col-xl-4 col-md-4 mb-30">
                        <div className="single-cta">
                        <i class="bi bi-telephone-fill"></i>
                            <div className="cta-text">
                                <h4>Call us</h4>
                                <span>9876543210 0</span>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-4 col-md-4 mb-30">
                        <div className="single-cta">
                        <i class="bi bi-envelope-heart"></i>
                            <div className="cta-text">
                                <h4>Mail us</h4>
                                <span>mail@info.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </footer>
        </section> */}
        <Footer/>
        </>
      );
}

export default Cdt;