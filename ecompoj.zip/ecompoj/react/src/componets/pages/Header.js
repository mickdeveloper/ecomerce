
import { useContext, useState } from 'react';
import './Navbar.css'; // Import your CSS file for styling
import { Modal, ModalBody, ModalHeader, Row, Col } from 'reactstrap'
import { Link } from 'react-router-dom';
import { Contentapi } from '../Admin/Contentapi';

const Navbar = () => {

//     const [isSignUpActive, setIsSignUpActive] = useState(true);

//   const togglePanel = () => {
//     setIsSignUpActive(!isSignUpActive);
//   };


//     const signUpButton = document.getElementById('signUp');
// const signInButton = document.getElementById('signIn');
// const container = document.getElementById('container');

// signUpButton.addEventListener('click', () => {
// 	container.classNameList.add("right-panel-active");
// });

// signInButton.addEventListener('click', () => {
// 	container.classNameList.remove("right-panel-active");
// });
    const [modal, setModal] = useState(false)
    const {cart}=useContext(Contentapi)
    // console.log(cart)
   
  return (
  
  <>
  <nav className = "navbar navbar-expand-lg navbar-light bg-white py-4 fixed-top">
  <div className = 'container'>
    
      <Link className = "navbar-brand d-flex justify-content-between align-items-center order-lg-0" to = '/'>
          <img src = "logo-sk.png" alt = "site icon" />
          <span className = "text-uppercase fw-lighter ms-2"></span>
      </Link>

      <div className = "order-lg-2 nav-btns">
        <Link to={'/cart'}>  <button type = "button" className = "btn position-relative">
              <i className = "fa fa-shopping-cart"></i>
              <span className = "position-absolute top-0 start-100 translate-middle badge bg-primary">{!cart.totalitems?0:cart.totalitems}</span>
          </button></Link>
          <button type = "button" className = "btn position-relative">
          <i className="bi bi-person-circle"></i>
             
          </button>
          {/* <button type = "button" className = "btn position-relative">
              <i className = "fa fa-search"></i>
          </button> */}
      </div>

      <button className = "navbar-toggler border-0" type = "button" data-bs-toggle = "collapse" data-bs-target = "#navMenu">
          <span className = "navbar-toggler-icon"></span>
      </button>

      <div className = "collapse navbar-collapse order-lg-1" id = "navMenu">
          <ul className = "navbar-nav mx-auto text-center">
              <li className = "nav-item px-2 py-2">
                  <Link className = "nav-link text-uppercase text-dark" to = {"/"}>Home</Link>
              </li>
              <li className = "nav-item px-2 py-2">
                  <Link className = "nav-link text-uppercase text-dark" to = {"/pdt"}>collection</Link>
              </li>
              <li className = "nav-item px-2 py-2">
                  <Link className = "nav-link text-uppercase text-dark" to = {"#pdt"}>About us</Link>
              </li>
              <li className = "nav-item px-2 py-2">
                  <Link className = "nav-link text-uppercase text-dark" to = {"/contact"}>Contact</Link>
              </li>
              <li className = "nav-item px-2 py-2">
                  <Link className = "nav-link text-uppercase text-dark" to ={''}  onClick={() => setModal(true)}>Your Account</Link>
              </li>
             
          </ul>
      </div>
  </div>
</nav>



<Modal
                size="md"
                
                isOpen={modal}
               
                toggle={() => setModal(!modal)}
                // onClosed={
                //   ()=>{}
                //  }
              >
                <ModalHeader
                  toggle={() => setModal(!modal)}
                  
                >

                Welcome,
               
                </ModalHeader>
                <ModalBody>
                   <div id='reg'>
                <form >
  <h2>Login Here</h2>
  

  <div className="input-container">
    <i className="fa fa-envelope icon"></i>
    <input className="input-field" type="text" placeholder="Email" name="email" />
  </div>

  <div className="input-container">
    <i className="fa fa-key icon"></i>
    <input className="input-field" type="password" placeholder="Password" name="psw" />
  </div>

  <button type="submit" className="btn">login</button>
</form>
</div> 
               
                </ModalBody>
              </Modal>


{/* <div class="superNav border-bottom py-2 bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 centerOnMobile">
            <select  class="me-3 border-0 bg-light">
              <option value="en-us">EN-US</option>
            </select>
            <span class="d-none d-lg-inline-block d-md-inline-block d-sm-inline-block d-xs-none me-3"><strong>info@somedomain.com</strong></span>
            <span class="me-3"><i class="fa-solid fa-phone me-1 text-warning"></i> <strong>1-800-123-1234</strong></span>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 d-none d-lg-block d-md-block-d-sm-block d-xs-none text-end">
            <span class="me-3"><i class="fa-solid fa-truck text-muted me-1"></i><a class="text-muted" href="#">Shipping</a></span>
            <span class="me-3"><i class="fa-solid fa-file  text-muted me-2"></i><a class="text-muted" href="#">Policy</a></span>
          </div>
        </div>
      </div>
    </div> */}
    

</>
  
  );
  
};

export default Navbar;
