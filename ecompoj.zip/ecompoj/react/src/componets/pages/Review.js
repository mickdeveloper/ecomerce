import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';


const productReviews = [
  {
    id: 1,
    image: 'images/pc5.jpg',
    comment: 'This product is amazing! I love it!',
    buyerName: 'John Doe',
  },
  {
    id: 4,
    image: 'images/pc5.jpg',
    comment: 'This product is amazing! I love it!',
    buyerName: 'John Doe',
  },
  {
    id: 5,
    image: 'images/pc5.jpg',
    comment: 'This product is amazing! I love it!',
    buyerName: 'John Doe',
  },
  {
    id: 6,
    image: 'images/pc5.jpg',
    comment: 'This product is amazing! I love it!',
    buyerName: 'John Doe',
  },
  {
    id: 2,
    image: 'images/pc5.jpg',
    comment: 'Great quality and fast delivery.',
    buyerName: 'Jane Smith',
  },
  {
    id: 3,
    image: 'images/pc5.jpg',
    comment: 'I highly recommend this product!',
    buyerName: 'Alice Johnson',
  },
];

const ProductReviewCarousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true, // Enable autoplay
    autoplaySpeed: 2000, // Set autoplay speed in milliseconds
    arrow:true,
    
  };

  return (
    <>
    <div className="product-review-carousel overflow-hidden border pt-3 mt-2 pb-4">
      <h2>Reviews</h2>
      <Slider {...settings}>
        {productReviews.map((review) => (
            <div className='  p-5'>
          <div key={review.id}>
            <img  className='img-fluid' style={{maxHeight:'200px', width:'100%'}} src={review.image} alt={`Product Review ${review.id}`} />
            <p className="review-comment">{review.comment}</p>
            <p className="buyer-name">- {review.buyerName}</p>
          </div>
          </div>
        ))}
      </Slider>
    </div>
   
    </>
  );
}

export default ProductReviewCarousel;
