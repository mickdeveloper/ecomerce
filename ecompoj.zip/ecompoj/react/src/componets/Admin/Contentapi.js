import {createContext} from 'react'




export const  Contentapi = createContext(null)