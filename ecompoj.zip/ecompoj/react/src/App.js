
import './App.css';
import Home from './componets/Home';
import {BrowserRouter as Router ,Route ,Routes } from 'react-router-dom'
import Products from './componets/pages/Products';
import Footer from './componets/pages/Footer';
import Cdt from './componets/pages/Cdt';
import Pdtdeatils from './componets/pages/pdtdeatils';
import Adminreg from './componets/Admin/AdminReg';
import { useState } from 'react';
import { Contentapi } from './componets/Admin/Contentapi';
import Login from './componets/Admin/Login';
import AdSidebar from './componets/Admin/AdSidebar';
import Dashboard from './componets/Admin/Dashboard';
import AdminH from './componets/Admin/AdminH';
import AdBanner from './componets/Admin/AdBanner';
import Adminpdt from './componets/Admin/Admindpdt';
import Editpdt from './componets/Admin/Editpdt';
import AddToCartButton from './componets/pages/AddToCartButton';

import ShoppingCart from './componets/pages/Cart';
import Navbar from './componets/pages/Header';


function App() {
  const [cart,setcart]=useState('')
  const [loginname,setloginname]=useState(window.localStorage.getItem('email'))
  return (
   <>
   <Router>
   <Contentapi.Provider value={{loginname,setloginname,cart,setcart}}>
    <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/pdt' element={<Products/>}></Route>
      <Route path='/footer' element={<Footer/>}></Route>
      <Route path='/headers' element={<Navbar/>}></Route>
      <Route path='/contact' element={<Cdt/>}></Route>
      <Route path='/pdtdeatils/:id' element={<Pdtdeatils  />}></Route>
      <Route path='/adminsignup' element={<Adminreg/>}></Route>
     

      <Route path='/adminlogin' element={<Login/>}></Route>
      <Route path='/adminsidebar' element={<AdSidebar/>}></Route>
      <Route path='/dashboard' element={<Dashboard/>}></Route>
      <Route path='/adminh' element={<AdminH/>}></Route>
      <Route path='/banner' element={<AdBanner/>}></Route>
      <Route path='/adminpdt' element={<Adminpdt/>}></Route>
      <Route path='/editpdt/:id' element={<Editpdt/>}></Route>
      <Route path='/addtocart' element={<AddToCartButton/>}></Route>
      <Route path='/cart' element={<ShoppingCart/>}></Route>

    
      
      
   
    </Routes>
    </Contentapi.Provider>
   </Router>

   </>
  );
}

export default App;
